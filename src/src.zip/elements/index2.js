import Grid2 from "../elements/Grid";
import Image2 from "../elements/Image";
import Text2 from "../elements/Text";
import Input2 from "../elements/Input";
import Button2 from "../elements/Button";

export { Grid2, Image2, Text2, Input2, Button2 };
