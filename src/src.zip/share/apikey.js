const apikey = {
  api: "http://13.125.39.34",
};

export { apikey };
