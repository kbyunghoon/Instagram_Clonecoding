const config = {
  api: "http://3.36.111.14",
};

export { config };
